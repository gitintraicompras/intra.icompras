@extends('layouts.app')
@section('content')
@include('layouts.login')
@endsection

